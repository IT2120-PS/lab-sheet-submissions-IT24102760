#Exercise 1:
#Question 1:population mean and variance
##Setting the directory
setwd("C:\\Users\\USER\\OneDrive - Sri Lanka Institute of Information Technology\\Desktop\\IT24102760")
##Importing the data set
data <- read.table("Data - Lab 8.txt", header=TRUE)
fix(data)
attach (data)
popmn <- mean (Nicotine)
popvar <- var (Nicotine)

##Question 02
#First create null vectors to store sample data sets.
samples <- c()
n <- c()
for(i in 1:30){
  S <- sample(Nicotine, 5, replace = TRUE)
  samples <- cbind(samples, S)
  n <- c(n, paste('S', i))
}
colnames(samples) <- n
s.means <- apply(samples, 2, mean)
s.vars  <- apply(samples, 2, var)


##Question 03:mean and variance of sample means
samplemean <- mean (s.means)
samplevars <- var (s.means)


#Question 04:Compare the population mean and mean
popmn
samplemean

#Question 05:Compare and state relationship
sample_means <- c()
sample_vars  <- c()

for (i in 1:30) {
  samp <- sample(Nicotine, 5, replace = TRUE)
  sample_means[i] <- mean(samp)
  sample_vars[i]  <- var(samp)
}

# Create results table
result <- data.frame(
  Sample   = 1:30,
  Mean     = round(sample_means, 2),
  Variance = round(sample_vars, 2)
)

print(result)

#Exercise 2:
# Setting the working directory
setwd("C:\\Users\\USER\\OneDrive - Sri Lanka Institute of Information Technology\\Desktop\\IT24102760")
getwd()

# Load the dataset
data <- read.table("Exercise - LaptopsWeights.txt", header = TRUE)
attach(data)

# Question 1: Population statistics
popmn <- mean(Weight.kg.)
pop_dev <- sd(Weight.kg.)

# view Population Mean
popmn         
# view Population Standard Deviation
pop_dev       

# Question 2: 25 random samples of size 6 with replacement
set.seed(123)

samples <- matrix(nrow = 6, ncol = 25)

for (i in 1:25) {
  samples[, i] <- sample(Weight.kg., size = 6, replace = TRUE)
}

# Calculate sample means standard deviations
s.means <- apply(samples, 2, mean)
# Calculate standard deviations
s.dev <- apply(samples, 2, sd)

# View sample means 
s.means
# View sample standard deviations
s.dev

# Question 3: Mean and SD of the sample means
samplemean <- mean(s.means)
sampledev <- sd(s.means)

# Mean of Sample Means
samplemean
# SD of Sample Means
sampledev
# True Population Mean
popmn 
# True Population SD
pop_dev     

